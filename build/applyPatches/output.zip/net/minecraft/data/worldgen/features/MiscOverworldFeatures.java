package net.minecraft.data.worldgen.features;

import com.google.common.collect.ImmutableSet;
import java.util.List;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.levelgen.feature.ConfiguredFeature;
import net.minecraft.world.level.levelgen.feature.Feature;
import net.minecraft.world.level.levelgen.feature.LakeFeature;
import net.minecraft.world.level.levelgen.feature.configurations.BlockStateConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.DiskConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.FeatureConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.NoneFeatureConfiguration;
import net.minecraft.world.level.levelgen.feature.configurations.SpringConfiguration;
import net.minecraft.world.level.levelgen.feature.stateproviders.BlockStateProvider;
import net.minecraft.world.level.material.Fluids;

public class MiscOverworldFeatures {
   public static final ConfiguredFeature<NoneFeatureConfiguration, ?> f_195010_ = FeatureUtils.m_195005_("ice_spike", Feature.f_65773_.m_65815_(FeatureConfiguration.f_67737_));
   public static final ConfiguredFeature<DiskConfiguration, ?> f_195011_ = FeatureUtils.m_195005_("ice_patch", Feature.f_65782_.m_65815_(new DiskConfiguration(Blocks.f_50354_.m_49966_(), UniformInt.m_146622_(2, 3), 1, List.of(Blocks.f_50493_.m_49966_(), Blocks.f_50440_.m_49966_(), Blocks.f_50599_.m_49966_(), Blocks.f_50546_.m_49966_(), Blocks.f_50195_.m_49966_(), Blocks.f_50127_.m_49966_(), Blocks.f_50126_.m_49966_()))));
   public static final ConfiguredFeature<BlockStateConfiguration, ?> f_195012_ = FeatureUtils.m_195005_("forest_rock", Feature.f_65780_.m_65815_(new BlockStateConfiguration(Blocks.f_50079_.m_49966_())));
   public static final ConfiguredFeature<BlockStateConfiguration, ?> f_195013_ = FeatureUtils.m_195005_("iceberg_packed", Feature.f_65779_.m_65815_(new BlockStateConfiguration(Blocks.f_50354_.m_49966_())));
   public static final ConfiguredFeature<BlockStateConfiguration, ?> f_195014_ = FeatureUtils.m_195005_("iceberg_blue", Feature.f_65779_.m_65815_(new BlockStateConfiguration(Blocks.f_50568_.m_49966_())));
   public static final ConfiguredFeature<NoneFeatureConfiguration, ?> f_195015_ = FeatureUtils.m_195005_("blue_ice", Feature.f_65778_.m_65815_(FeatureConfiguration.f_67737_));
   public static final ConfiguredFeature<LakeFeature.Configuration, ?> f_195016_ = FeatureUtils.m_195005_("lake_lava", Feature.f_65783_.m_65815_(new LakeFeature.Configuration(BlockStateProvider.m_191384_(Blocks.f_49991_.m_49966_()), BlockStateProvider.m_191384_(Blocks.f_50069_.m_49966_()))));
   public static final ConfiguredFeature<DiskConfiguration, ?> f_195017_ = FeatureUtils.m_195005_("disk_clay", Feature.f_65781_.m_65815_(new DiskConfiguration(Blocks.f_50129_.m_49966_(), UniformInt.m_146622_(2, 3), 1, List.of(Blocks.f_50493_.m_49966_(), Blocks.f_50129_.m_49966_()))));
   public static final ConfiguredFeature<DiskConfiguration, ?> f_195018_ = FeatureUtils.m_195005_("disk_gravel", Feature.f_65781_.m_65815_(new DiskConfiguration(Blocks.f_49994_.m_49966_(), UniformInt.m_146622_(2, 5), 2, List.of(Blocks.f_50493_.m_49966_(), Blocks.f_50440_.m_49966_()))));
   public static final ConfiguredFeature<DiskConfiguration, ?> f_195019_ = FeatureUtils.m_195005_("disk_sand", Feature.f_65781_.m_65815_(new DiskConfiguration(Blocks.f_49992_.m_49966_(), UniformInt.m_146622_(2, 6), 2, List.of(Blocks.f_50493_.m_49966_(), Blocks.f_50440_.m_49966_()))));
   public static final ConfiguredFeature<?, ?> f_195020_ = FeatureUtils.m_195005_("freeze_top_layer", Feature.f_65775_.m_65815_(FeatureConfiguration.f_67737_));
   public static final ConfiguredFeature<?, ?> f_195021_ = FeatureUtils.m_195005_("bonus_chest", Feature.f_65751_.m_65815_(FeatureConfiguration.f_67737_));
   public static final ConfiguredFeature<?, ?> f_195022_ = FeatureUtils.m_195005_("void_start_platform", Feature.f_65768_.m_65815_(FeatureConfiguration.f_67737_));
   public static final ConfiguredFeature<NoneFeatureConfiguration, ?> f_195023_ = FeatureUtils.m_195005_("desert_well", Feature.f_65769_.m_65815_(FeatureConfiguration.f_67737_));
   public static final ConfiguredFeature<SpringConfiguration, ?> f_195024_ = FeatureUtils.m_195005_("spring_lava_overworld", Feature.f_65765_.m_65815_(new SpringConfiguration(Fluids.f_76195_.m_76145_(), true, 4, 1, ImmutableSet.of(Blocks.f_50069_, Blocks.f_50122_, Blocks.f_50228_, Blocks.f_50334_, Blocks.f_152550_, Blocks.f_152496_, Blocks.f_152497_, Blocks.f_50493_))));
   public static final ConfiguredFeature<SpringConfiguration, ?> f_195025_ = FeatureUtils.m_195005_("spring_lava_frozen", Feature.f_65765_.m_65815_(new SpringConfiguration(Fluids.f_76195_.m_76145_(), true, 4, 1, ImmutableSet.of(Blocks.f_50127_, Blocks.f_152499_, Blocks.f_50354_))));
   public static final ConfiguredFeature<SpringConfiguration, ?> f_195026_ = FeatureUtils.m_195005_("spring_water", Feature.f_65765_.m_65815_(new SpringConfiguration(Fluids.f_76193_.m_76145_(), true, 4, 1, ImmutableSet.of(Blocks.f_50069_, Blocks.f_50122_, Blocks.f_50228_, Blocks.f_50334_, Blocks.f_152550_, Blocks.f_152496_, Blocks.f_152497_, Blocks.f_50493_, Blocks.f_50127_, Blocks.f_152499_, Blocks.f_50354_))));
}