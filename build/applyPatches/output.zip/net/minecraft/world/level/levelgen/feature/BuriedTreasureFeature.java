package net.minecraft.world.level.levelgen.feature;

import com.mojang.serialization.Codec;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.ChunkPos;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.level.levelgen.LegacyRandomSource;
import net.minecraft.world.level.levelgen.WorldgenRandom;
import net.minecraft.world.level.levelgen.feature.configurations.ProbabilityFeatureConfiguration;
import net.minecraft.world.level.levelgen.structure.BuriedTreasurePieces;
import net.minecraft.world.level.levelgen.structure.pieces.PieceGenerator;
import net.minecraft.world.level.levelgen.structure.pieces.PieceGeneratorSupplier;
import net.minecraft.world.level.levelgen.structure.pieces.StructurePiecesBuilder;

public class BuriedTreasureFeature extends StructureFeature<ProbabilityFeatureConfiguration> {
   private static final int f_159478_ = 10387320;

   public BuriedTreasureFeature(Codec<ProbabilityFeatureConfiguration> p_65313_) {
      super(p_65313_, PieceGeneratorSupplier.m_197349_(BuriedTreasureFeature::m_197072_, BuriedTreasureFeature::m_197074_));
   }

   private static boolean m_197072_(PieceGeneratorSupplier.Context<ProbabilityFeatureConfiguration> p_197073_) {
      WorldgenRandom worldgenrandom = new WorldgenRandom(new LegacyRandomSource(0L));
      worldgenrandom.m_190058_(p_197073_.f_197354_(), p_197073_.f_197355_().f_45578_, p_197073_.f_197355_().f_45579_, 10387320);
      return worldgenrandom.nextFloat() < (p_197073_.f_197356_()).f_67859_ && p_197073_.m_197380_(Heightmap.Types.OCEAN_FLOOR_WG);
   }

   private static void m_197074_(StructurePiecesBuilder p_197075_, PieceGenerator.Context<ProbabilityFeatureConfiguration> p_197076_) {
      BlockPos blockpos = new BlockPos(p_197076_.f_192705_().m_151382_(9), 90, p_197076_.f_192705_().m_151391_(9));
      p_197075_.m_142679_(new BuriedTreasurePieces.BuriedTreasurePiece(blockpos));
   }

   public BlockPos m_183220_(ChunkPos p_190798_) {
      return new BlockPos(p_190798_.m_151382_(9), 0, p_190798_.m_151391_(9));
   }
}