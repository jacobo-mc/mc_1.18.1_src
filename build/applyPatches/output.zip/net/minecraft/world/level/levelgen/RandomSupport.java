package net.minecraft.world.level.levelgen;

import com.google.common.annotations.VisibleForTesting;
import java.util.concurrent.atomic.AtomicLong;

public final class RandomSupport {
   public static final long f_189323_ = -7046029254386353131L;
   public static final long f_189324_ = 7640891576956012809L;
   private static final AtomicLong f_189325_ = new AtomicLong(8682522807148012L);

   @VisibleForTesting
   public static long m_189329_(long p_189330_) {
      p_189330_ = (p_189330_ ^ p_189330_ >>> 30) * -4658895280553007687L;
      p_189330_ = (p_189330_ ^ p_189330_ >>> 27) * -7723592293110705685L;
      return p_189330_ ^ p_189330_ >>> 31;
   }

   public static RandomSupport.Seed128bit m_189331_(long p_189332_) {
      long i = p_189332_ ^ 7640891576956012809L;
      long j = i + -7046029254386353131L;
      return new RandomSupport.Seed128bit(m_189329_(i), m_189329_(j));
   }

   public static long m_189328_() {
      return f_189325_.updateAndGet((p_189334_) -> {
         return p_189334_ * 1181783497276652981L;
      }) ^ System.nanoTime();
   }

   public static record Seed128bit(long f_189335_, long f_189336_) {
   }
}