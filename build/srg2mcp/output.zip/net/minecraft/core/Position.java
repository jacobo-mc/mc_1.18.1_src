package net.minecraft.core;

public interface Position {
   double x();

   double y();

   double z();
}